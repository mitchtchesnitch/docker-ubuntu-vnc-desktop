
$(document).ready(function(){

        //foxyProxy = new Extension();
        //foxyProxy.log.clear();
        //foxyProxy.state = localStorage.getItem('state');

});
// 
// // var getCurrentTabUrl = function (callback) {
// //     chrome.tabs.getSelected(null, function(tab) {
// //         callback(tab.url);
// //     });
// // };
// 
// var ProfileManager;
// var foxyProxy;
// function copyToClipboard(str) {
//     var obj=document.getElementById("hbnaclhngkhpmpgmfakaghgjbblokeeh");
//     if( obj ){
//         obj.value = str;
//         obj.select();
//         document.execCommand("copy", false, null);
//     }
// }